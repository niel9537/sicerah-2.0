<?php

namespace App\Services;

use App\Models\Indikator;
use Illuminate\Support\Collection;

class IndicatorDataService
{
    public function __construct(private readonly IndicatorValueParser $parser)
    {
    }

    /**
     * @param  array<int>  $years
     * @return array<string,mixed>
     */
    public function present(Indikator $indicator, array $years, int $selectedYear): array
    {
        $targets = $indicator->relationLoaded('targets') ? $indicator->targets : collect();
        $realisations = $indicator->relationLoaded('realisasis') ? $indicator->realisasis : collect();
        $points = [];

        foreach ($years as $year) {
            $targetModel = $targets->firstWhere('tahun', $year);
            $actualModel = $this->lastRealisation($realisations, $year);
            $target = $this->parser->parse($targetModel?->getRawOriginal('target'));
            $actual = $this->parser->parse($actualModel?->getRawOriginal('realisasi'));
            $hasActual = $actual['type'] !== 'empty';
            $hasTarget = $target['type'] !== 'empty';
            $chosen = $hasActual ? $actual : $target;

            $points[$year] = [
                'year' => $year,
                'source' => $hasActual ? 'capaian' : ($hasTarget ? 'target' : null),
                'raw' => $chosen['raw'],
                'type' => $chosen['type'],
                'graph' => $chosen['graph'],
                'min' => $chosen['min'],
                'max' => $chosen['max'],
                'target_raw' => $target['raw'],
                'target_graph' => $target['graph'],
                'actual_raw' => $actual['raw'],
                'actual_graph' => $actual['graph'],
                'updated_at' => collect([$targetModel?->updated_at, $actualModel?->updated_at, $indicator->updated_at])
                    ->filter()->sort()->last(),
            ];
        }

        $selected = $points[$selectedYear] ?? [
            'year' => $selectedYear,
            'source' => null,
            'raw' => null,
            'type' => 'empty',
            'graph' => null,
            'min' => null,
            'max' => null,
            'updated_at' => null,
        ];

        return [
            'id' => $indicator->id,
            'kode' => $indicator->kode,
            'nama' => $indicator->nama,
            'satuan' => $indicator->satuan,
            'aspek' => $indicator->aspek,
            'is_iku' => (bool) $indicator->is_iku,
            'is_makro' => (bool) $indicator->is_makro,
            'sumber_data' => $indicator->sumber_data,
            'keterangan' => $indicator->keterangan,
            'selected' => $selected,
            'points' => array_values($points),
            'has_chart' => collect($points)->contains(fn (array $point) => $point['graph'] !== null),
        ];
    }

    private function lastRealisation(Collection $realisations, int $year): mixed
    {
        return $realisations
            ->where('tahun', $year)
            ->filter(fn ($item) => $this->parser->parse($item->getRawOriginal('realisasi'))['type'] !== 'empty')
            ->sortByDesc('triwulan')
            ->first();
    }
}
