<?php

namespace App\Http\Controllers;

use App\Models\EvaluasiRenja;
use App\Models\Indikator;
use App\Models\JdihDokumen;
use App\Models\Lkpj;
use App\Models\Opd;
use App\Models\RealisasiTriwulanan;
use App\Models\SubKegiatan;
use App\Services\IndicatorDataService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class LandingController extends Controller
{
    public function index(Request $request, IndicatorDataService $indicatorData): View
    {
        $tahunRange = range(2020, 2030);
        $tahun = (int) $request->integer('tahun', min(max((int) now()->year, 2020), 2030));
        if (! in_array($tahun, $tahunRange, true)) {
            $tahun = min(max((int) now()->year, 2020), 2030);
        }

        $indicatorModels = Indikator::ikd()
            ->bankData()
            ->with([
                'targets' => fn ($query) => $query->whereBetween('tahun', [2020, 2030]),
                'realisasis' => fn ($query) => $query->whereBetween('tahun', [2020, 2030]),
            ])
            ->orderBy('urutan')
            ->get();

        $indikatorDaerah = $indicatorModels
            ->map(fn (Indikator $indicator) => $indicatorData->present($indicator, $tahunRange, $tahun))
            ->values();

        $capaianIku = $indikatorDaerah->where('is_iku', true)->values();
        $indikatorMakro = $indikatorDaerah->where('is_makro', true)->values();
        $aspek = $indicatorModels->groupBy('aspek')->map->count();

        $counts = [
            'iku' => $capaianIku->count(),
            'ikk' => Indikator::ikk()->count(),
            'ikd' => $indikatorDaerah->count(),
            'makro' => $indikatorMakro->count(),
            'aspek' => $aspek->count(),
            'opd' => Opd::whereNotNull('nama')->count(),
            'subkegiatan' => SubKegiatan::count(),
            'lkpj' => Lkpj::where('tahun', $tahun)->count(),
            'evaluasi' => EvaluasiRenja::whereHas('periode', fn ($query) => $query->where('tahun', $tahun))->count(),
            'jdih' => JdihDokumen::published()->count(),
        ];

        $kinerja = $this->kinerjaDaerah($tahun);
        $tren = ['labels' => ['TW I', 'TW II', 'TW III', 'TW IV'], 'realisasi' => []];
        foreach ([1, 2, 3, 4] as $quarter) {
            $tren['realisasi'][] = round(
                RealisasiTriwulanan::where('tahun', $tahun)->where('triwulan', $quarter)->sum('realisasi_anggaran') / 1_000_000,
                0
            );
        }

        $jdihTerbaru = JdihDokumen::published()
            ->orderByDesc('tahun')
            ->orderByDesc('created_at')
            ->limit(4)
            ->get();

        $opdList = Opd::whereNotNull('nama')->orderBy('nama')->get();
        $terakhirDiperbarui = collect($indikatorDaerah)
            ->flatMap(fn (array $item) => collect($item['points'])->pluck('updated_at'))
            ->merge($kinerja['timestamps'])
            ->filter()
            ->sort()
            ->last();

        unset($kinerja['timestamps']);

        return view('landing', compact(
            'tahun', 'tahunRange', 'counts', 'aspek', 'indikatorDaerah',
            'capaianIku', 'indikatorMakro', 'kinerja', 'tren',
            'jdihTerbaru', 'opdList', 'terakhirDiperbarui'
        ));
    }

    /** @return array<string,mixed> */
    private function kinerjaDaerah(int $tahun): array
    {
        $quarter = (int) (RealisasiTriwulanan::where('tahun', $tahun)
            ->whereNotNull('realisasi_anggaran')->max('triwulan') ?: 4);

        $subActivities = SubKegiatan::with([
            'targetTahunans' => fn ($query) => $query->where('tahun', $tahun),
            'realisasiTriwulanans' => fn ($query) => $query->where('tahun', $tahun)->where('triwulan', $quarter),
        ])->get();

        $physical = collect();
        $financial = collect();
        $budget = 0.0;
        $realised = 0.0;
        $timestamps = collect();

        foreach ($subActivities as $subActivity) {
            $target = $subActivity->targetTahunans->first();
            $actual = $subActivity->realisasiTriwulanans->first();
            $physicalTarget = (float) ($target->target_kinerja ?? 0);
            $physicalActual = (float) ($actual->realisasi_kinerja ?? 0);
            $effectiveBudget = $target ? (float) $target->paguEfektif() : 0.0;
            $actualBudget = (float) ($actual->realisasi_anggaran ?? 0);

            if ($physicalTarget > 0) {
                $physical->push(min(200, round($physicalActual / $physicalTarget * 100, 1)));
            }
            if ($effectiveBudget > 0) {
                $financial->push(min(200, round($actualBudget / $effectiveBudget * 100, 1)));
            }

            $budget += $effectiveBudget;
            $realised += $actualBudget;
            if ($actual?->updated_at) {
                $timestamps->push($actual->updated_at);
            }
        }

        return [
            'rata_fisik' => $physical->isNotEmpty() ? round((float) $physical->avg(), 1) : 0,
            'rata_keuangan' => $financial->isNotEmpty() ? round((float) $financial->avg(), 1) : 0,
            'total_pagu' => $budget,
            'total_realisasi' => $realised,
            'triwulan' => $quarter,
            'timestamps' => $timestamps,
        ];
    }
}
