<?php

namespace App\Http\Controllers;

use App\Models\EvaluasiRenja;
use App\Models\Indikator;
use App\Models\Lkpj;
use App\Models\RealisasiTriwulanan;
use App\Models\SubKegiatan;
use App\Models\TargetTahunan;
use App\Services\IndicatorDataService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(Request $request, IndicatorDataService $indicatorData): View
    {
        $tahun = (int) $request->input('tahun', now()->year);

        $stats = [
            'iku'      => Indikator::iku()->count(),
            'ikk'      => Indikator::ikk()->count(),
            'ikd'      => Indikator::ikd()->bankData()->count(),
            'makro'    => Indikator::makro()->count(),
            'lkpj'     => Lkpj::where('tahun', $tahun)->count(),
            'evaluasi' => EvaluasiRenja::whereHas('periode', fn ($q) => $q->where('tahun', $tahun))->count(),
        ];

        $bankIndicators = Indikator::ikd()->bankData()->with([
            'targets' => fn ($query) => $query->whereBetween('tahun', [2020, 2030]),
            'realisasis' => fn ($query) => $query->whereBetween('tahun', [2020, 2030]),
        ])->orderBy('urutan')->get();
        $presentedIndicators = $bankIndicators->map(
            fn (Indikator $indicator) => $indicatorData->present($indicator, range(2020, 2030), $tahun)
        );
        $indicatorOverview = [
            'numeric' => $presentedIndicators->whereNotNull('selected.graph')->count(),
            'text' => $presentedIndicators->where('selected.type', 'text')->count(),
            'empty' => $presentedIndicators->where('selected.type', 'empty')->count(),
            'aspects' => $bankIndicators->whereNotNull('aspek')->groupBy('aspek')->map->count(),
        ];
        $macroHighlights = $presentedIndicators->where('is_makro', true)->take(6)->values();

        // Progress pengisian: berapa sub kegiatan yg sudah punya realisasi TW berjalan
        $totalSub    = SubKegiatan::count();
        $sudahIsiTw  = [];
        foreach ([1, 2, 3, 4] as $tw) {
            $sudahIsiTw[$tw] = RealisasiTriwulanan::forPeriode($tahun, $tw)->count();
        }

        // Grafik: total anggaran vs realisasi per triwulan (dalam juta)
        $chart = ['labels' => ['TW I', 'TW II', 'TW III', 'TW IV'], 'target' => [], 'realisasi' => []];
        //$totalTarget = (float) TargetTahunan::where('tahun', $tahun)->sum('pagu_renja');
        $totalTarget = TargetTahunan::where('tahun', $tahun)->get()->sum(fn ($t) => $t->paguEfektif());
        foreach ([1, 2, 3, 4] as $tw) {
            $chart['target'][]    = round($totalTarget / 1_000_000, 0);
            $chart['realisasi'][] = round(RealisasiTriwulanan::forPeriode($tahun, $tw)->sum('realisasi_anggaran') / 1_000_000, 0);
        }

        // Aktivitas terbaru
        $aktivitas = EvaluasiRenja::with(['subKegiatan', 'periode', 'creator'])
            ->latest()->limit(5)->get();

        // Kapan data kinerja tahun ini (realisasi triwulanan maupun evaluasi renja)
        // terakhir disentuh — dipakai untuk banner freshness di puncak dashboard,
        // supaya siapapun yang login langsung tahu seberapa baru angka yang mereka lihat.
        $terakhirDiperbarui = collect()
            ->push(RealisasiTriwulanan::where('tahun', $tahun)->max('updated_at'))
            ->push(EvaluasiRenja::whereHas('periode', fn ($q) => $q->where('tahun', $tahun))->max('updated_at'))
            ->filter()
            ->map(fn ($t) => \Illuminate\Support\Carbon::parse($t))
            ->sort()
            ->last();

        return view('dashboard', compact('stats', 'sudahIsiTw', 'totalSub', 'chart', 'aktivitas', 'tahun', 'terakhirDiperbarui', 'indicatorOverview', 'macroHighlights'));
    }
}
