<?php

namespace App\Http\Controllers;

use App\Models\GisArea;
use App\Models\GisLayer;
use App\Models\GisValue;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WebGisController extends Controller
{
    public function index(Request $request): View
    {
        $layers = GisLayer::where('is_active', true)->where('is_public', true)->orderBy('sort_order')->orderBy('name')->get();
        $activeLayer = $layers->firstWhere('slug', $request->string('layer')->toString()) ?? $layers->first();
        $years = $activeLayer
            ? GisValue::where('gis_layer_id', $activeLayer->id)->distinct()->orderByDesc('year')->pluck('year')
            : collect();
        $areas = GisArea::orderBy('district_name')->orderBy('name')->get();

        return view('webgis.index', compact('layers', 'activeLayer', 'years', 'areas'));
    }

    public function data(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'layer' => 'required|string|max:160',
            'year' => 'required|integer|min:2000|max:2100',
        ]);

        $layer = GisLayer::where('slug', $validated['layer'])->where('is_active', true)->where('is_public', true)->firstOrFail();
        $values = GisValue::with('area')
            ->where('gis_layer_id', $layer->id)
            ->where('year', $validated['year'])
            ->get()
            ->map(fn (GisValue $value) => [
                'area_code' => $value->area_code,
                'area_name' => $value->area?->name,
                'district_name' => $value->area?->district_name,
                'raw_value' => $value->raw_value,
                'value_type' => $value->value_type,
                'numeric_value' => $value->numeric_value,
                'value_min' => $value->value_min,
                'value_max' => $value->value_max,
            ]);

        return response()->json([
            'layer' => [
                'name' => $layer->name,
                'unit' => $layer->unit,
                'geojson_url' => asset($layer->geojson_path),
                'color_from' => $layer->color_from,
                'color_to' => $layer->color_to,
                'breakpoints' => $layer->breakpoints,
            ],
            'year' => (int) $validated['year'],
            'values' => $values,
        ]);
    }
}
