<?php $__env->startSection('title', 'Manajemen WebGIS'); ?>
<?php $__env->startSection('subtitle', 'Layer tematik, tampilan, dan data per desa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['items' => ['WebGIS' => route('webgis.index'), 'Manajemen Layer' => '']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['WebGIS' => route('webgis.index'), 'Manajemen Layer' => ''])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    <div class="grid xl:grid-cols-[380px_1fr] gap-5 items-start">
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['title' => 'Tambah Layer Tematik','subtitle' => 'Gunakan batas desa bawaan atau unggah GeoJSON baru','class' => 'xl:sticky xl:top-24']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tambah Layer Tematik','subtitle' => 'Gunakan batas desa bawaan atau unggah GeoJSON baru','class' => 'xl:sticky xl:top-24']); ?>
            <form method="POST" action="<?php echo e(route('webgis.admin.store')); ?>" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div><label class="block text-xs font-medium text-slate-600 mb-1">Nama layer</label><input name="name" required class="input" placeholder="Contoh: Kemiskinan Ekstrem"></div>
                <div class="grid grid-cols-2 gap-3"><div><label class="block text-xs font-medium text-slate-600 mb-1">Satuan</label><input name="unit" class="input" placeholder="Persen"></div><div><label class="block text-xs font-medium text-slate-600 mb-1">Urutan</label><input type="number" name="sort_order" min="0" value="0" class="input"></div></div>
                <div><label class="block text-xs font-medium text-slate-600 mb-1">Deskripsi</label><textarea name="description" rows="2" class="textarea"></textarea></div>
                <div class="grid grid-cols-2 gap-3"><label class="text-xs text-slate-600">Warna rendah<input type="color" name="color_from" value="#fee2e2" class="mt-1 block h-10 w-full rounded-lg border border-slate-200"></label><label class="text-xs text-slate-600">Warna tinggi<input type="color" name="color_to" value="#7f1d1d" class="mt-1 block h-10 w-full rounded-lg border border-slate-200"></label></div>
                <div><label class="block text-xs font-medium text-slate-600 mb-1">Batas klasifikasi</label><input name="breakpoints_text" class="input" placeholder="5, 10, 15, 20, 30"><p class="text-[11px] text-slate-400 mt-1">Pisahkan dengan koma. Kosongkan untuk skala otomatis.</p></div>
                <div><label class="block text-xs font-medium text-slate-600 mb-1">GeoJSON opsional</label><input type="file" name="geojson" accept=".json,.geojson" class="input"><p class="text-[11px] text-slate-400 mt-1">Jika kosong, layer memakai batas 105 desa Nias Barat.</p></div>
                <div class="grid grid-cols-2 gap-3"><label class="flex items-center gap-2 text-sm"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" value="1" checked class="rounded text-maroon-700"> Aktif</label><label class="flex items-center gap-2 text-sm"><input type="hidden" name="is_public" value="0"><input type="checkbox" name="is_public" value="1" checked class="rounded text-maroon-700"> Publik</label></div>
                <button class="btn-primary w-full justify-center">Tambah Layer</button>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

        <div class="space-y-4">
            <div class="flex items-center justify-between gap-3"><div><h2 class="font-bold text-slate-900">Layer tersedia</h2><p class="text-xs text-slate-500 mt-1"><?php echo e($layers->count()); ?> layer terdaftar</p></div><a href="<?php echo e(route('webgis.index')); ?>" target="_blank" class="btn-secondary btn-sm">Lihat Peta Publik</a></div>

            <?php $__empty_1 = true; $__currentLoopData = $layers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <details class="card overflow-hidden" <?php if($loop->first): ?> open <?php endif; ?>>
                    <summary class="list-none cursor-pointer p-5 flex items-center gap-4">
                        <span class="w-3 h-12 rounded-full shrink-0" style="background:linear-gradient(<?php echo e($layer->color_from); ?>,<?php echo e($layer->color_to); ?>)"></span>
                        <div class="flex-1 min-w-0"><div class="flex flex-wrap gap-2 items-center"><h3 class="font-bold text-slate-900"><?php echo e($layer->name); ?></h3><?php if($layer->is_active): ?><span class="badge-success">Aktif</span><?php else: ?><span class="badge-default">Nonaktif</span><?php endif; ?> <?php if($layer->is_public): ?><span class="badge-info">Publik</span><?php endif; ?></div><p class="text-xs text-slate-500 mt-1"><?php echo e($layer->values_count); ?> nilai · slug <?php echo e($layer->slug); ?></p></div>
                        <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-width="2" d="m6 9 6 6 6-6"/></svg>
                    </summary>
                    <div class="border-t border-slate-100 p-5 grid lg:grid-cols-2 gap-6">
                        <form method="POST" action="<?php echo e(route('webgis.admin.update', $layer)); ?>" enctype="multipart/form-data" class="space-y-3">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Pengaturan layer</p>
                            <div class="grid sm:grid-cols-2 gap-3"><input name="name" value="<?php echo e($layer->name); ?>" required class="input" aria-label="Nama layer"><input name="slug" value="<?php echo e($layer->slug); ?>" required class="input" aria-label="Slug"></div>
                            <div class="grid grid-cols-2 gap-3"><input name="unit" value="<?php echo e($layer->unit); ?>" class="input" placeholder="Satuan"><input type="number" name="sort_order" min="0" value="<?php echo e($layer->sort_order); ?>" class="input" placeholder="Urutan"></div>
                            <textarea name="description" rows="2" class="textarea" placeholder="Deskripsi"><?php echo e($layer->description); ?></textarea>
                            <div class="grid grid-cols-2 gap-3"><input type="color" name="color_from" value="<?php echo e($layer->color_from); ?>" class="h-10 w-full rounded-lg border border-slate-200"><input type="color" name="color_to" value="<?php echo e($layer->color_to); ?>" class="h-10 w-full rounded-lg border border-slate-200"></div>
                            <input name="breakpoints_text" value="<?php echo e(collect($layer->breakpoints)->implode(', ')); ?>" class="input" placeholder="5, 10, 15, 20, 30">
                            <input type="file" name="geojson" accept=".json,.geojson" class="input">
                            <div class="flex gap-4"><label class="flex items-center gap-2 text-sm"><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" value="1" <?php if($layer->is_active): echo 'checked'; endif; ?> class="rounded text-maroon-700"> Aktif</label><label class="flex items-center gap-2 text-sm"><input type="hidden" name="is_public" value="0"><input type="checkbox" name="is_public" value="1" <?php if($layer->is_public): echo 'checked'; endif; ?> class="rounded text-maroon-700"> Publik</label></div>
                            <button class="btn-primary btn-sm">Simpan Pengaturan</button>
                        </form>

                        <div>
                            <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Impor nilai per desa</p>
                            <p class="text-xs text-slate-500 mt-2 leading-5">Unggah Excel atau CSV dengan header <strong>kode_desa</strong>, <strong>tahun</strong>, dan <strong>nilai</strong>. Nilai rentang maupun desimal koma/titik akan dinormalisasi untuk pewarnaan peta, sementara teks aslinya tetap disimpan.</p>
                            <form method="POST" action="<?php echo e(route('webgis.admin.values.import', $layer)); ?>" enctype="multipart/form-data" class="mt-3 space-y-3">
                                <?php echo csrf_field(); ?>
                                <input type="file" name="file" accept=".xlsx,.xls,.csv" required class="input">
                                <button class="btn-secondary btn-sm">Impor Data Layer</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('webgis.admin.destroy', $layer)); ?>" onsubmit="return confirm('Hapus layer dan semua datanya?')" class="mt-6 pt-4 border-t border-slate-100">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-xs font-semibold text-red-600 hover:text-red-800">Hapus layer ini</button>
                            </form>
                        </div>
                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Belum ada layer WebGIS','description' => 'Tambahkan layer pertama melalui formulir.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Belum ada layer WebGIS','description' => 'Tambahkan layer pertama melalui formulir.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bappeli4/public_html/resources/views/webgis/admin.blade.php ENDPATH**/ ?>