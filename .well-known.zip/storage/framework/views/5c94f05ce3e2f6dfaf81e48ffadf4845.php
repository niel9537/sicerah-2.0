<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Kode Program</label>
            <input type="text" name="kode" value="<?php echo e(old('kode', $program->kode ?? '')); ?>"
                   class="input" placeholder="Cth: 1.01.01">
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Urusan <span class="text-red-500">*</span></label>
            <select name="urusan_id" required class="select">
                <option value="">— Pilih Urusan —</option>
                <?php $__currentLoopData = $urusanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php if(old('urusan_id', $program->urusan_id ?? null) == $u->id): echo 'selected'; endif; ?>>
                        <?php echo e($u->kode); ?> — <?php echo e($u->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Nama Program <span class="text-red-500">*</span></label>
        <input type="text" name="nama" value="<?php echo e(old('nama', $program->nama ?? '')); ?>" required class="input">
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">OPD Pengampu <span class="text-red-500">*</span></label>
            <select name="opd_id" required class="select">
                <option value="">— Pilih OPD —</option>
                <?php $__currentLoopData = $opdList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($o->id); ?>" <?php if(old('opd_id', $program->opd_id ?? null) == $o->id): echo 'selected'; endif; ?>><?php echo e($o->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Sasaran PD Terkait</label>
            <select name="sasaran_pd_id" class="select">
                <option value="">— Tidak ada —</option>
                <?php $__currentLoopData = $sasaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(old('sasaran_pd_id', $program->sasaran_pd_id ?? null) == $s->id): echo 'selected'; endif; ?>><?php echo e($s->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div><?php /**PATH /home/bappeli4/public_html/resources/views/master/program/_form.blade.php ENDPATH**/ ?>