
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'at' => null,
    'label' => 'Diperbarui',
    'emptyText' => 'Belum ada data',
    'variant' => 'chip',
    'icon' => true,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'at' => null,
    'label' => 'Diperbarui',
    'emptyText' => 'Belum ada data',
    'variant' => 'chip',
    'icon' => true,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $carbon = null;

    if ($at instanceof \Illuminate\Support\Carbon) {
        $carbon = $at;
    } elseif ($at instanceof \DateTimeInterface) {
        $carbon = \Illuminate\Support\Carbon::instance($at);
    } elseif (is_string($at) && trim($at) !== '') {
        try {
            $carbon = \Illuminate\Support\Carbon::parse($at);
        } catch (\Throwable $e) {
            $carbon = null;
        }
    }

    $relatif = null;
    $exact = null;
    $stale = false; // lebih dari 90 hari dianggap perlu perhatian

    if ($carbon) {
        $exact = $carbon->format('d/m/Y H:i');
        $detik = (int) abs($carbon->diffInSeconds(now()));

        if ($detik < 60) {
            $relatif = 'baru saja';
        } elseif ($detik < 3600) {
            $relatif = intdiv($detik, 60) . ' menit yang lalu';
        } elseif ($detik < 86400) {
            $relatif = intdiv($detik, 3600) . ' jam yang lalu';
        } elseif ($detik < 86400 * 7) {
            $relatif = intdiv($detik, 86400) . ' hari yang lalu';
        } elseif ($detik < 86400 * 30) {
            $relatif = intdiv($detik, 86400 * 7) . ' minggu yang lalu';
        } elseif ($detik < 86400 * 365) {
            $relatif = intdiv($detik, 86400 * 30) . ' bulan yang lalu';
        } else {
            $relatif = intdiv($detik, 86400 * 365) . ' tahun yang lalu';
        }

        $stale = $detik > (86400 * 90);
    }

    $dotClass = ! $carbon
        ? 'bg-slate-300'
        : ($stale ? 'bg-amber-500' : 'bg-emerald-500');

    $teks = $carbon
        ? trim(($label !== '' ? "{$label} " : '') . $relatif)
        : $emptyText;
?>

<?php if($variant === 'chip'): ?>
    <span <?php echo e($attributes->merge(['class' => 'inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-[11px] font-medium text-slate-600'])); ?>

          <?php if($exact): ?> title="<?php echo e(trim($label . ' ' . $exact)); ?>" <?php endif; ?>>
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotClass); ?> flex-shrink-0"></span>
        <?php if($icon): ?>
            <svg class="w-3 h-3 flex-shrink-0 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
        <?php endif; ?>
        <span><?php echo e($teks); ?></span>
    </span>
<?php else: ?>
    <span <?php echo e($attributes->merge(['class' => 'inline-flex items-center gap-1 text-xs text-slate-400'])); ?>

          <?php if($exact): ?> title="<?php echo e(trim($label . ' ' . $exact)); ?>" <?php endif; ?>>
        <?php if($icon): ?>
            <svg class="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
        <?php endif; ?>
        <?php echo e($teks); ?>

    </span>
<?php endif; ?>
<?php /**PATH /home/bappeli4/public_html/resources/views/components/ui/updated-badge.blade.php ENDPATH**/ ?>