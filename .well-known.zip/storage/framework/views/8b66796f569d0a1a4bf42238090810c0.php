

<?php $__env->startSection('title', 'Kelola Capaian Indikator'); ?>
<?php $__env->startSection('subtitle', Str::limit($indikator->nama, 80)); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['items' => ['Indikator' => route('indikator.index', ['jenis' => $indikator->jenis]), Str::limit($indikator->nama, 40) => '']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Indikator' => route('indikator.index', ['jenis' => $indikator->jenis]), Str::limit($indikator->nama, 40) => ''])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
        <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 text-sm flex-1">
                <div>
                    <p class="text-xs text-slate-500">Jenis</p>
                    <p><span class="badge-maroon"><?php echo e($indikator->jenis); ?></span></p>
                </div>
                <div>
                    <p class="text-xs text-slate-500">OPD Pengampu</p>
                    <p class="font-medium"><?php echo e($indikator->opd?->nama ?? '— Tidak terikat OPD —'); ?></p>
                </div>
                <div>
                    <p class="text-xs text-slate-500">Satuan</p>
                    <p class="font-medium"><?php echo e($indikator->satuan ?? '-'); ?></p>
                </div>
                <div>
                    <p class="text-xs text-slate-500">Sumber Data</p>
                    <p class="font-medium"><?php echo e($indikator->sumber_data ?? '-'); ?></p>
                </div>
            </div>

            <?php if (isset($component)) { $__componentOriginal1aec35162f840bd9141758b6bc366566 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1aec35162f840bd9141758b6bc366566 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.updated-badge','data' => ['at' => $terakhirDiperbarui,'label' => 'Capaian diperbarui','class' => 'flex-shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.updated-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($terakhirDiperbarui),'label' => 'Capaian diperbarui','class' => 'flex-shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $attributes = $__attributesOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__attributesOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $component = $__componentOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__componentOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

    
    <?php if($adaDataGrafik): ?>
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['title' => 'Tren Capaian '.e(reset($rentangTahun)).'–'.e(end($rentangTahun)).'','subtitle' => 'Persentase capaian tahunan (realisasi terakhir yang tercatat ÷ target)','class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tren Capaian '.e(reset($rentangTahun)).'–'.e(end($rentangTahun)).'','subtitle' => 'Persentase capaian tahunan (realisasi terakhir yang tercatat ÷ target)','class' => 'mb-4']); ?>
            <?php if($adaNilaiDilewati): ?>
                <p class="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mb-4 flex items-start gap-2">
                    <svg class="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-8.99 4.5h.01" />
                    </svg>
                    <span>Sebagian tahun berisi target/realisasi berupa teks (bukan angka), jadi titik tahun itu dilewati dari grafik ini. Nilai aslinya tetap tersimpan dan bisa dicek di tabel bawah.</span>
                </p>
            <?php endif; ?>
            <canvas id="chartIndikator" height="80"></canvas>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
            <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Grafik belum bisa ditampilkan','description' => 'Target & realisasi indikator ini belum berupa angka yang valid, jadi belum ada yang bisa digambar. Isi datanya di tabel bawah ini — grafik akan otomatis muncul begitu ada nilai numerik.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Grafik belum bisa ditampilkan','description' => 'Target & realisasi indikator ini belum berupa angka yang valid, jadi belum ada yang bisa digambar. Isi datanya di tabel bawah ini — grafik akan otomatis muncul begitu ada nilai numerik.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['title' => 'Input Target & Realisasi Triwulanan','subtitle' => 'Semua tahun '.e(reset($rentangTahun)).'–'.e(end($rentangTahun)).' tersedia. Kosongkan nilai lalu simpan untuk menghapus.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Input Target & Realisasi Triwulanan','subtitle' => 'Semua tahun '.e(reset($rentangTahun)).'–'.e(end($rentangTahun)).' tersedia. Kosongkan nilai lalu simpan untuk menghapus.']); ?>
        <div class="overflow-x-auto -mx-6 sm:mx-0 sm:rounded-xl border border-slate-100">
            <table class="table-modern min-w-full">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap w-28">Tahun</th>
                        <th class="whitespace-nowrap">Target</th>
                        <th class="whitespace-nowrap">Realisasi TW I</th>
                        <th class="whitespace-nowrap">Realisasi TW II</th>
                        <th class="whitespace-nowrap">Realisasi TW III</th>
                        <th class="whitespace-nowrap">Realisasi TW IV</th>
                        <th class="whitespace-nowrap w-32">Capaian TW IV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rentangTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $target    = $baris[$tahun]['target'];
                            $realisasi = $baris[$tahun]['realisasi'];

                            $parser = app(\App\Services\IndicatorValueParser::class);
                            $targetRaw = $target?->getRawOriginal('target');
                            $targetParsed = $parser->parse($targetRaw);
                            $targetVal = $targetParsed['graph'];

                            $realisasiRaw = null;
                            foreach ([4,3,2,1] as $tw) {
                                $val = isset($realisasi[$tw]) ? $realisasi[$tw]->getRawOriginal('realisasi') : null;
                                if ($val !== null && trim((string) $val) !== '') {
                                    $realisasiRaw = $val;
                                    break;
                                }
                            }
                            $realisasiParsed = $parser->parse($realisasiRaw);
                            $realTerakhir = $realisasiParsed['graph'];

                            $capaian = ($targetVal !== null && $targetVal > 0 && $realTerakhir !== null)
                                ? round($realTerakhir / $targetVal * 100, 1)
                                : null;

                            // Ada isinya tapi bukan angka? beda kasusnya dengan "belum diisi sama sekali".
                            $capaianBukanAngka = ($realisasiRaw !== null && $realTerakhir === null)
                                || ($targetRaw !== null && trim((string) $targetRaw) !== '' && $targetVal === null);
                        ?>
                        <tr class="align-top">
                            
                            <td class="pt-4">
                                <span class="font-semibold text-slate-800 block"><?php echo e($tahun); ?></span>
                                <?php if (isset($component)) { $__componentOriginal1aec35162f840bd9141758b6bc366566 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1aec35162f840bd9141758b6bc366566 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.updated-badge','data' => ['at' => $baris[$tahun]['updated_at'],'variant' => 'text','label' => '','emptyText' => 'Belum diisi','icon' => false,'class' => 'mt-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.updated-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($baris[$tahun]['updated_at']),'variant' => 'text','label' => '','emptyText' => 'Belum diisi','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'class' => 'mt-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $attributes = $__attributesOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__attributesOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $component = $__componentOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__componentOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
                            </td>

                            
                            <td>
                                <form method="POST" action="<?php echo e(route('indikator.target.simpan', ['indikator' => $indikator->id, 'tahun' => $tahun])); ?>"
                                      class="flex items-center gap-1">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" inputmode="text" name="target"
                                           value="<?php echo e(old('target', $targetRaw)); ?>"
                                           class="input !py-1.5 !text-xs w-28" placeholder="—">
                                    <button type="submit" class="btn-primary btn-sm !px-2" title="Simpan target">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                        </svg>
                                    </button>
                                </form>
                            </td>

                            
                            <?php $__currentLoopData = [1, 2, 3, 4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $r = $realisasi[$tw] ?? null; ?>
                                <td>
                                    <form method="POST" action="<?php echo e(route('indikator.realisasi.simpan', ['indikator' => $indikator->id, 'tahun' => $tahun, 'triwulan' => $tw])); ?>"
                                          class="space-y-1">
                                        <?php echo csrf_field(); ?>
                                        <div class="flex items-center gap-1">
                                            <input type="text" inputmode="text" name="realisasi"
                                                   value="<?php echo e(old('realisasi', $r?->getRawOriginal('realisasi') ?? '')); ?>"
                                                   class="input !py-1.5 !text-xs w-24" placeholder="—">
                                            <button type="submit" class="btn-primary btn-sm !px-2" title="Simpan TW <?php echo e(['I','II','III','IV'][$tw-1]); ?>">
                                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                                </svg>
                                            </button>
                                        </div>
                                        <select name="status" class="select !py-1 !text-[10px] !pr-6">
                                            <option value="draft" <?php if(($r->status ?? 'draft') === 'draft'): echo 'selected'; endif; ?>>Draft</option>
                                            <option value="diajukan" <?php if(($r->status ?? '') === 'diajukan'): echo 'selected'; endif; ?>>Diajukan</option>
                                            <option value="diverifikasi" <?php if(($r->status ?? '') === 'diverifikasi'): echo 'selected'; endif; ?>>Diverifikasi</option>
                                            <option value="ditolak" <?php if(($r->status ?? '') === 'ditolak'): echo 'selected'; endif; ?>>Ditolak</option>
                                        </select>
                                        <?php if($r?->updated_at): ?>
                                            <?php if (isset($component)) { $__componentOriginal1aec35162f840bd9141758b6bc366566 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1aec35162f840bd9141758b6bc366566 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.updated-badge','data' => ['at' => $r->updated_at,'variant' => 'text','label' => '','icon' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.updated-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($r->updated_at),'variant' => 'text','label' => '','icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $attributes = $__attributesOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__attributesOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $component = $__componentOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__componentOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <td class="pt-4">
                                <?php if($capaian !== null): ?>
                                    <span class="badge-<?php echo e($capaian >= 100 ? 'success' : ($capaian >= 50 ? 'warning' : 'danger')); ?>">
                                        <?php echo e(number_format($capaian, 1)); ?>%
                                    </span>
                                <?php elseif($capaianBukanAngka): ?>
                                    <span class="text-xs text-amber-600" title="Target atau realisasi berisi teks, bukan angka">Nilai teks</span>
                                <?php else: ?>
                                    <span class="text-xs text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <p class="text-xs text-slate-400 mt-3">
            Nilai realisasi bersifat <strong>kumulatif</strong> sepanjang tahun. Nilai rentang digambar memakai titik tengah, sedangkan teks biasa tetap tampil di tabel tanpa dipaksa menjadi nol.
            Capaian dihitung dari realisasi triwulan terakhir yang tercatat dibagi target tahun tersebut.
            Tanda <span class="inline-flex items-center gap-1"><svg class="w-3 h-3 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg> waktu</span> di tiap baris/sel menunjukkan kapan nilai itu terakhir disimpan.
        </p>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

    <?php if($adaDataGrafik): ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        if (typeof Chart !== 'undefined') Chart.defaults.font.family = "'Inter', sans-serif";
        (function () {
            const ctx = document.getElementById('chartIndikator');
            if (!ctx) return;

            const grad = ctx.getContext('2d').createLinearGradient(0, 0, 0, 260);
            grad.addColorStop(0, 'rgba(139,30,48,.35)');
            grad.addColorStop(1, 'rgba(139,30,48,0)');

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_map('strval', $rentangTahun), 512) ?>,
                    datasets: [
                        {
                            type: 'line',
                            label: 'Capaian (%)',
                            data: <?php echo json_encode(array_values($grafikCapaian), 15, 512) ?>,
                            borderColor: '#8b1e30',
                            backgroundColor: grad,
                            fill: true,
                            tension: 0.35,
                            pointRadius: 5,
                            pointBackgroundColor: '#8b1e30',
                            yAxisID: 'yCapaian',
                            // Nilai null (tahun dengan target/realisasi bukan angka) sengaja
                            // TIDAK disambung jadi garis — biar keliatan sebagai celah, bukan
                            // seolah-olah datanya menurun/naik mulus padahal cuma kosong.
                            spanGaps: false,
                            order: 0,
                        },
                        {
                            type: 'bar',
                            label: 'Target',
                            data: <?php echo json_encode(array_values($grafikTarget), 15, 512) ?>,
                            backgroundColor: 'rgba(148, 163, 184, .5)',
                            borderRadius: 6,
                            yAxisID: 'yNilai',
                            order: 2,
                        },
                        {
                            type: 'bar',
                            label: 'Realisasi',
                            data: <?php echo json_encode(array_values($grafikRealisasi), 15, 512) ?>,
                            backgroundColor: 'rgba(220, 72, 85, .8)',
                            borderRadius: 6,
                            yAxisID: 'yNilai',
                            order: 1,
                        },
                    ],
                },
                options: {
                    responsive: true,
                    interaction: { mode: 'index', intersect: false },
                    plugins: {
                        legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } },
                        tooltip: {
                            callbacks: {
                                label: (c) => c.parsed.y === null
                                    ? c.dataset.label + ': bukan angka'
                                    : c.dataset.label + ': ' + c.parsed.y.toLocaleString('id-ID') + (c.dataset.yAxisID === 'yCapaian' ? '%' : ''),
                            },
                        },
                    },
                    scales: {
                        yNilai: {
                            beginAtZero: true,
                            position: 'left',
                            title: { display: true, text: 'Nilai (<?php echo e($indikator->satuan ?? ''); ?>)' },
                        },
                        yCapaian: {
                            beginAtZero: true,
                            position: 'right',
                            grid: { drawOnChartArea: false },
                            ticks: { callback: v => v + '%' },
                            title: { display: true, text: 'Capaian (%)' },
                        },
                    },
                },
            });
        })();
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bappeli4/public_html/resources/views/indikator/kelola.blade.php ENDPATH**/ ?>