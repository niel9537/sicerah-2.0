

<?php $__env->startSection('title', 'Indikator Kinerja'); ?>
<?php $__env->startSection('subtitle', $jenis === 'MAKRO' ? 'Kelola indikator makro daerah' : 'Kelola indikator ' . $jenis); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['items' => ['Indikator' => '', $jenis => '']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Indikator' => '', $jenis => ''])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">

        <div class="flex flex-wrap gap-2">
            <?php $__currentLoopData = ['IKD' => 'Semua Bank Data', 'IKU' => 'Utama', 'MAKRO' => 'Makro', 'IKK' => 'Kunci']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('indikator.index', ['jenis' => $code])); ?>"
                    class="px-4 py-2 rounded-xl text-sm font-medium transition duration-200
                    <?php echo e($jenis === $code
                        ? 'bg-brand-gradient text-white shadow-soft'
                        : 'bg-white text-slate-600 border border-slate-200 hover:border-red-300 hover:text-red-700 hover:shadow-sm'); ?>">
                    <?php echo e($code); ?>

                    <span class="text-xs opacity-75">
                        (<?php echo e($label); ?>)
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('indikator.import.form', ['jenis' => $jenis])); ?>"
                class="btn-secondary btn-sm inline-flex items-center gap-2 whitespace-nowrap">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                </svg>
                Impor Excel
            </a>

            <button
                @click="$dispatch('open-modal-indikator-create')"
                class="btn-primary btn-sm inline-flex items-center gap-2 whitespace-nowrap">

                <svg class="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>

                Tambah <?php echo e($jenis); ?>

            </button>
        </div>

    </div>

    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 mb-5">
            <input type="hidden" name="jenis" value="<?php echo e($jenis); ?>">

            <input
                type="text"
                name="q"
                value="<?php echo e($q); ?>"
                placeholder="Cari indikator..."
                class="input">

            <select
                name="aspek"
                class="select"
                onchange="this.form.submit()">

                <option value="">Semua Aspek</option>

                <?php $__currentLoopData = $aspekList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaAspek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($namaAspek); ?>" <?php if($aspek === $namaAspek): echo 'selected'; endif; ?>>
                        <?php echo e(Str::headline(Str::lower(str_replace('ASPEK ', '', $namaAspek)))); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

            <select
                name="opd_id"
                class="select"
                onchange="this.form.submit()">

                <option value="">Semua OPD</option>

                <?php $__currentLoopData = $opdList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($o->id); ?>"
                        <?php if($opdId == $o->id): echo 'selected'; endif; ?>>
                        <?php echo e($o->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

            <button
                type="submit"
                class="btn-secondary justify-center">
                Filter
            </button>

        </form>

        <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table','data' => ['headers' => ['Kode', 'Nama Indikator', 'Kelompok', 'Aspek', 'Satuan', 'Sumber Data', 'Aksi']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Kode', 'Nama Indikator', 'Kelompok', 'Aspek', 'Satuan', 'Sumber Data', 'Aksi'])]); ?>

            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td class="text-xs text-slate-500 whitespace-nowrap"><?php echo e($item->kode ?? '—'); ?></td>

                    <td class="font-medium text-slate-800 max-w-sm">
                        <?php echo e($item->nama); ?>

                    </td>

                    <td class="text-xs whitespace-nowrap">
                        <?php if($item->jenis === 'IKK'): ?>
                            <span class="badge-warning">IKK</span>
                        <?php elseif($item->jenis === 'IKU' && !$item->is_iku): ?>
                            <span class="badge-maroon">IKU</span>
                        <?php else: ?>
                            <span class="badge-info">IKD</span>
                        <?php endif; ?>
                        <?php if($item->is_iku): ?><span class="badge-maroon">IKU</span><?php endif; ?>
                        <?php if($item->is_makro): ?><span class="badge-success">Makro</span><?php endif; ?>
                    </td>

                    <td class="text-xs max-w-xs">
                        <?php echo e($item->aspek ? Str::headline(Str::lower(str_replace('ASPEK ', '', $item->aspek))) : '—'); ?>

                    </td>

                    <td>
                        <span class="badge-info">
                            <?php echo e($item->satuan ?? '-'); ?>

                        </span>
                    </td>

                    <td class="text-xs">
                        <?php echo e($item->sumber_data ?? '-'); ?>

                    </td>

                    <td>

                        <div class="flex items-center gap-1">

                            <a href="<?php echo e(route('indikator.kelola', ['indikator' => $item->id])); ?>" class="btn-secondary btn-sm">Kelola Capaian</a>

                            <button
                                @click='$dispatch("open-modal-indikator-edit-<?php echo e($item->id); ?>")'
                                class="btn-secondary btn-sm">

                                Ubah

                            </button>

                            <form
                                method="POST"
                                action="<?php echo e(route('indikator.destroy', $item)); ?>"
                                onsubmit="return confirm('Hapus indikator ini?')">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button
                                    type="submit"
                                    class="btn-danger btn-sm">

                                    Hapus

                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

                <?php if (isset($component)) { $__componentOriginal7762953202be6518eecd1cfbd075bf2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7762953202be6518eecd1cfbd075bf2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.modal','data' => ['id' => 'indikator-edit-'.e($item->id).'','title' => 'Ubah Indikator','size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'indikator-edit-'.e($item->id).'','title' => 'Ubah Indikator','size' => 'lg']); ?>

                    <form
                        method="POST"
                        action="<?php echo e(route('indikator.update', $item)); ?>"
                        id="form-indikator-edit-<?php echo e($item->id); ?>">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <?php echo $__env->make('indikator._form', [
                            'indikator' => $item,
                            'opdList' => $opdList,
                            'urusanList' => $urusanList,
                            'sasaranList' => $sasaranList
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    </form>

                     <?php $__env->slot('footer', null, []); ?> 

                        <button
                            type="button"
                            @click='$dispatch("close-modal-indikator-edit-<?php echo e($item->id); ?>")'
                            class="btn-secondary btn-sm">

                            Batal

                        </button>

                        <button
                            type="submit"
                            form="form-indikator-edit-<?php echo e($item->id); ?>"
                            class="btn-primary btn-sm">

                            Simpan Perubahan

                        </button>

                     <?php $__env->endSlot(); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7762953202be6518eecd1cfbd075bf2f)): ?>
<?php $attributes = $__attributesOriginal7762953202be6518eecd1cfbd075bf2f; ?>
<?php unset($__attributesOriginal7762953202be6518eecd1cfbd075bf2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7762953202be6518eecd1cfbd075bf2f)): ?>
<?php $component = $__componentOriginal7762953202be6518eecd1cfbd075bf2f; ?>
<?php unset($__componentOriginal7762953202be6518eecd1cfbd075bf2f); ?>
<?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>
                    <td colspan="7">
                        <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Belum ada indikator '.e($jenis).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Belum ada indikator '.e($jenis).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
                    </td>
                </tr>

            <?php endif; ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>

        <div class="mt-4">
            <?php echo e($items->links()); ?>

        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7762953202be6518eecd1cfbd075bf2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7762953202be6518eecd1cfbd075bf2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.modal','data' => ['id' => 'indikator-create','title' => 'Tambah Indikator '.e($jenis).'','size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'indikator-create','title' => 'Tambah Indikator '.e($jenis).'','size' => 'lg']); ?>

        <form
            method="POST"
            action="<?php echo e(route('indikator.store')); ?>"
            id="form-indikator-create">

            <?php echo csrf_field(); ?>

            <?php echo $__env->make('indikator._form', [
                'indikator' => null,
                'jenisDefault' => $jenis === 'MAKRO' ? 'IKD' : $jenis,
                'isMakroDefault' => $jenis === 'MAKRO',
                'opdList' => $opdList,
                'urusanList' => $urusanList,
                'sasaranList' => $sasaranList
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </form>

         <?php $__env->slot('footer', null, []); ?> 

            <button
                type="button"
                @click="$dispatch('close-modal-indikator-create')"
                class="btn-secondary btn-sm">

                Batal

            </button>

            <button
                type="submit"
                form="form-indikator-create"
                class="btn-primary btn-sm">

                Simpan

            </button>

         <?php $__env->endSlot(); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7762953202be6518eecd1cfbd075bf2f)): ?>
<?php $attributes = $__attributesOriginal7762953202be6518eecd1cfbd075bf2f; ?>
<?php unset($__attributesOriginal7762953202be6518eecd1cfbd075bf2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7762953202be6518eecd1cfbd075bf2f)): ?>
<?php $component = $__componentOriginal7762953202be6518eecd1cfbd075bf2f; ?>
<?php unset($__componentOriginal7762953202be6518eecd1cfbd075bf2f); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bappeli4/public_html/resources/views/indikator/index.blade.php ENDPATH**/ ?>