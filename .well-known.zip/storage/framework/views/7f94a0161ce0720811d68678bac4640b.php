<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'value', 'icon' => null, 'color' => 'maroon', 'trend' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'value', 'icon' => null, 'color' => 'maroon', 'trend' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $colors = [
        'maroon'  => 'from-maroon-500 to-maroon-700',
        'blue'    => 'from-sky-500 to-sky-700',
        'green'   => 'from-emerald-500 to-emerald-700',
        'amber'   => 'from-amber-500 to-amber-700',
        'purple'  => 'from-purple-500 to-purple-700',
    ];
    $gradient = $colors[$color] ?? $colors['maroon'];
?>

<div <?php echo e($attributes->merge(['class' => 'card p-6 relative overflow-hidden group hover:shadow-soft transition-all'])); ?>>
    <div class="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-gradient-to-br <?php echo e($gradient); ?> opacity-10 group-hover:opacity-20 transition"></div>

    <div class="relative">
        <div class="flex items-center justify-between mb-3">
            <p class="text-xs font-medium uppercase tracking-wider text-slate-500"><?php echo e($label); ?></p>
            <?php if($icon): ?>
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br <?php echo e($gradient); ?> text-white flex items-center justify-center">
                    <?php echo $icon; ?>

                </div>
            <?php endif; ?>
        </div>
        <p class="text-3xl font-bold text-slate-800 tracking-tight"><?php echo e($value); ?></p>
        <?php if($trend): ?>
            <p class="text-xs text-slate-500 mt-2"><?php echo e($trend); ?></p>
        <?php endif; ?>
    </div>
</div><?php /**PATH /home/bappeli4/public_html/resources/views/components/ui/stat-card.blade.php ENDPATH**/ ?>