<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Kode Kegiatan</label>
            <input type="text" name="kode" value="<?php echo e(old('kode', $kegiatan->kode ?? '')); ?>"
                   class="input" placeholder="Cth: 1.01.01.01">
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Program <span class="text-red-500">*</span></label>
            <select name="program_id" required class="select">
                <option value="">— Pilih Program —</option>
                <?php $__currentLoopData = $programList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(old('program_id', $kegiatan->program_id ?? null) == $p->id): echo 'selected'; endif; ?>><?php echo e($p->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Nama Kegiatan <span class="text-red-500">*</span></label>
        <textarea name="nama" rows="2" required class="textarea"><?php echo e(old('nama', $kegiatan->nama ?? '')); ?></textarea>
    </div>
</div><?php /**PATH /home/bappeli4/public_html/resources/views/master/kegiatan/_form.blade.php ENDPATH**/ ?>