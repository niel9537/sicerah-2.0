<?php $__env->startSection('title', 'JDIH'); ?>
<?php $__env->startSection('meta_description', 'Jaringan Dokumentasi dan Informasi Hukum Bappelitbangda Kabupaten Nias Barat — RPJMD, RKPD, Renstra, Renja, Peraturan Daerah, dan Peraturan Bupati terkait perencanaan pembangunan daerah.'); ?>

<?php $__env->startSection('content'); ?>

    <section class="bg-brand-gradient text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-16">
            <p class="text-xs font-semibold uppercase tracking-widest text-[var(--sc-gold-tint)] mb-3">Dokumentasi Hukum</p>
            <h1 class="font-display font-semibold text-3xl sm:text-4xl">JDIH Bappelitbangda</h1>
            <p class="text-white/80 text-sm sm:text-base mt-3 max-w-2xl leading-relaxed">
                Jaringan Dokumentasi dan Informasi Hukum: kumpulan dokumen perencanaan dan regulasi
                yang menjadi dasar hukum SICERAH — RPJMD, RKPD, Renstra, Renja, Peraturan Daerah,
                dan Peraturan Bupati Kabupaten Nias Barat.
            </p>
        </div>
    </section>

    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 pb-20">
        <div class="card p-4 sm:p-5 mb-6">
            <form method="GET" class="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Cari judul dokumen…" class="input sm:col-span-2">

                <select name="kategori" class="select" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if($kategori === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <select name="tahun" class="select" onchange="this.form.submit()">
                    <option value="">Semua Tahun</option>
                    <?php $__currentLoopData = $tahunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($y); ?>" <?php if((string) $tahun === (string) $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit" class="btn-secondary justify-center sm:col-span-4">Terapkan Filter</button>
            </form>
        </div>

        <?php if($items->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Tidak ada dokumen ditemukan','description' => 'Coba ubah kata kunci atau filter kategori/tahun.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tidak ada dokumen ditemukan','description' => 'Coba ubah kata kunci atau filter kategori/tahun.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card p-5 flex flex-col">
                        <div class="flex items-center justify-between mb-3">
                            <span class="badge-default"><?php echo e($doc->kategoriLabel()); ?></span>
                            <?php if($doc->tahun): ?><span class="text-xs text-slate-400"><?php echo e($doc->tahun); ?></span><?php endif; ?>
                        </div>

                        <h3 class="font-semibold text-slate-800 text-sm leading-snug flex-1"><?php echo e($doc->judul); ?></h3>

                        <?php if($doc->nomor): ?>
                            <p class="text-xs text-slate-500 mt-2">Nomor: <?php echo e($doc->nomor); ?></p>
                        <?php endif; ?>

                        <?php if($doc->ringkasan): ?>
                            <p class="text-xs text-slate-500 mt-2 leading-relaxed"><?php echo e(Str::limit($doc->ringkasan, 130)); ?></p>
                        <?php endif; ?>

                        <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                            <?php if (isset($component)) { $__componentOriginal1aec35162f840bd9141758b6bc366566 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1aec35162f840bd9141758b6bc366566 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.updated-badge','data' => ['at' => $doc->updated_at,'variant' => 'text','label' => 'Diperbarui']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.updated-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($doc->updated_at),'variant' => 'text','label' => 'Diperbarui']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $attributes = $__attributesOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__attributesOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1aec35162f840bd9141758b6bc366566)): ?>
<?php $component = $__componentOriginal1aec35162f840bd9141758b6bc366566; ?>
<?php unset($__componentOriginal1aec35162f840bd9141758b6bc366566); ?>
<?php endif; ?>
                            <?php if($doc->file_url): ?>
                                <a href="<?php echo e($doc->file_url); ?>" target="_blank" rel="noopener" class="text-xs font-semibold text-maroon-700 hover:text-maroon-900 inline-flex items-center gap-1">
                                    Lihat Dokumen
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                                </a>
                            <?php else: ?>
                                <span class="text-xs text-slate-400">Segera tersedia</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-8">
                <?php echo e($items->links()); ?>

            </div>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bappeli4/public_html/resources/views/jdih/index.blade.php ENDPATH**/ ?>