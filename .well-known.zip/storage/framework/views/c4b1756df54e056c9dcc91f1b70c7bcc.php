

<?php $__env->startSection('title', 'Form 81 — Evaluasi Renja'); ?>
<?php $__env->startSection('subtitle', 'Preview & Export Laporan Evaluasi Hasil Renja SKPD'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal045477955e5b1d8c9df01934ca3836c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal045477955e5b1d8c9df01934ca3836c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.breadcrumb','data' => ['items' => ['Form 81' => '']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Form 81' => ''])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $attributes = $__attributesOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__attributesOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal045477955e5b1d8c9df01934ca3836c0)): ?>
<?php $component = $__componentOriginal045477955e5b1d8c9df01934ca3836c0; ?>
<?php unset($__componentOriginal045477955e5b1d8c9df01934ca3836c0); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <select name="tahun" class="select">
                <?php $__currentLoopData = range(now()->year + 1, now()->year - 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y); ?>" <?php if($tahun == $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if(auth()->user()->role !== 'operator_opd'): ?>
                <select name="opd_id" class="select">
                    <option value="">— Seluruh SKPD —</option>
                    <?php $__currentLoopData = $opdList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o->id); ?>" <?php if($opdId == $o->id): echo 'selected'; endif; ?>><?php echo e($o->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>

            <button type="submit" class="btn-secondary justify-center">Terapkan Filter</button>

            <div class="flex gap-2">
                <a href="<?php echo e(route('form81.excel', request()->query())); ?>" class="btn-success btn flex-1 justify-center">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    Excel
                </a>
                <a href="<?php echo e(route('form81.pdf', request()->query())); ?>" class="btn-danger btn flex-1 justify-center">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    PDF
                </a>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-center mb-6">
            <h2 class="text-lg font-bold text-slate-800 uppercase">Evaluasi Terhadap Hasil Rencana Kerja SKPD</h2>
            <p class="text-sm text-slate-600">Pemerintah Kabupaten Nias Barat — Tahun <?php echo e($data['header']['tahun']); ?></p>
            <p class="text-sm font-semibold mt-1">SKPD: <?php echo e(strtoupper($data['header']['opd'])); ?></p>
        </div>

        <div class="overflow-x-auto -mx-6 sm:mx-0">
            <table class="min-w-full text-[10px] border-collapse">
                <thead class="bg-slate-100">
                    <tr>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2">No</th>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2">Kode</th>
                        <th rowspan="2" class="border border-slate-300 px-2 py-2 min-w-[240px] text-left">Urusan / Program / Kegiatan / Sub Kegiatan</th>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2 min-w-[120px]">Indikator</th>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2">Sat.</th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">Target Renja <?php echo e($data['header']['tahun']); ?></th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">TW I</th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">TW II</th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">TW III</th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">TW IV</th>
                        <th colspan="2" class="border border-slate-300 px-1 py-2">Realisasi s/d Tahun Berjalan</th>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2">Capaian %</th>
                        <th rowspan="2" class="border border-slate-300 px-1 py-2 min-w-[140px]">Unit SKPD</th>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = ['K','Rp','K','Rp','K','Rp','K','Rp','K','Rp','K','Rp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="border border-slate-300 px-1 py-1"><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $rowClass = match($r['level']) {
                                'urusan'   => 'bg-maroon-900 text-white font-bold',
                                'program'  => 'bg-maroon-600 text-white font-semibold',
                                'kegiatan' => 'bg-maroon-100 font-semibold',
                                default    => '',
                            };
                            $indent = ['urusan' => '', 'program' => 'pl-4', 'kegiatan' => 'pl-8', 'subkegiatan' => 'pl-12'][$r['level']];
                        ?>
                        <tr class="<?php echo e($rowClass); ?>">
                            <td class="border border-slate-300 px-1 py-1 text-center"><?php echo e($r['level'] === 'subkegiatan' ? $r['no'] : ''); ?></td>
                            <td class="border border-slate-300 px-1 py-1 font-mono text-[9px]"><?php echo e($r['kode']); ?></td>
                            <td class="border border-slate-300 px-2 py-1 <?php echo e($indent); ?>"><?php echo e($r['uraian']); ?></td>
                            <td class="border border-slate-300 px-1 py-1"><?php echo e($r['indikator']); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-center"><?php echo e($r['satuan']); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r['target_k'] !== null ? number_format($r['target_k'], 2, ',', '.') : ''); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r['target_rp'] !== null ? number_format($r['target_rp'], 0, ',', '.') : ''); ?></td>
                            <?php $__currentLoopData = [1,2,3,4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r["tw_{$tw}_k"] !== null ? number_format($r["tw_{$tw}_k"], 2, ',', '.') : ''); ?></td>
                                <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r["tw_{$tw}_rp"] !== null ? number_format($r["tw_{$tw}_rp"], 0, ',', '.') : ''); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r['real_k'] !== null ? number_format($r['real_k'], 2, ',', '.') : ''); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-right"><?php echo e($r['real_rp'] !== null ? number_format($r['real_rp'], 0, ',', '.') : ''); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-center"><?php echo e($r['pct_k'] !== null ? number_format($r['pct_k'], 1) . '%' : ''); ?></td>
                            <td class="border border-slate-300 px-1 py-1 text-[9px]"><?php echo e($r['opd']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <tr class="bg-maroon-50 font-bold">
                        <td colspan="6" class="border border-slate-300 px-2 py-2 text-right">TOTAL</td>
                        <td class="border border-slate-300 px-1 py-2 text-right"><?php echo e(number_format($data['footer']['total_target_rp'], 0, ',', '.')); ?></td>
                        <td colspan="8" class="border border-slate-300"></td>
                        <td class="border border-slate-300"></td>
                        <td class="border border-slate-300 px-1 py-2 text-right"><?php echo e(number_format($data['footer']['total_real_rp'], 0, ',', '.')); ?></td>
                        <td class="border border-slate-300 px-1 py-2 text-center"><?php echo e(number_format($data['footer']['rata_pct_rp'], 1)); ?>%</td>
                        <td class="border border-slate-300"></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="mt-6 flex justify-end">
            <div class="text-center text-sm">
                <p>Nias Barat, <?php echo e(now()->translatedFormat('d F Y')); ?></p>
                <p class="mt-1">Kepala SKPD</p>
                <p class="mt-16">(_______________________)</p>
                <p>NIP.</p>
            </div>
        </div>

        <div class="mt-4 text-xs text-slate-500 grid grid-cols-1 sm:grid-cols-4 gap-2 pt-4 border-t border-slate-100">
            <div>Jumlah Sub Kegiatan: <strong><?php echo e($data['footer']['jumlah_sub']); ?></strong></div>
            <div>Rata-rata Capaian Fisik: <strong><?php echo e(number_format($data['footer']['rata_pct_k'] ?? 0, 1)); ?>%</strong></div>
            <div>Rata-rata Capaian Keuangan: <strong><?php echo e(number_format($data['footer']['rata_pct_rp'] ?? 0, 1)); ?>%</strong></div>
            <div>Total Pagu: <strong>Rp <?php echo e(number_format($data['footer']['total_target_rp'], 0, ',', '.')); ?></strong></div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bappeli4/public_html/resources/views/form81/index.blade.php ENDPATH**/ ?>