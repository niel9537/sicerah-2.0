<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'subtitle' => null, 'icon' => null, 'padding' => 'p-6']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'subtitle' => null, 'icon' => null, 'padding' => 'p-6']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'card overflow-hidden'])); ?>>
    <?php if($title || $icon): ?>
        <div class="flex items-start justify-between px-6 py-4 border-b border-slate-100">
            <div class="flex items-start gap-3">
                <?php if($icon): ?>
                    <div class="w-10 h-10 rounded-xl bg-brand-gradient text-white flex items-center justify-center shadow-soft">
                        <?php echo $icon; ?>

                    </div>
                <?php endif; ?>
                <div>
                    <?php if($title): ?>   <h3 class="font-semibold text-slate-800"><?php echo e($title); ?></h3> <?php endif; ?>
                    <?php if($subtitle): ?><p class="text-xs text-slate-500 mt-0.5"><?php echo e($subtitle); ?></p> <?php endif; ?>
                </div>
            </div>
            <?php if(isset($actions)): ?>
                <div class="flex items-center gap-2"><?php echo e($actions); ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="<?php echo e($padding); ?>">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH /home/bappeli4/public_html/resources/views/components/ui/card.blade.php ENDPATH**/ ?>