<div class="space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Jenis <span class="text-red-500">*</span></label>
            <select name="jenis" required class="select">
                <option value="IKU" <?php if(old('jenis', $indikator->jenis ?? $jenisDefault ?? 'IKU') === 'IKU'): echo 'selected'; endif; ?>>IKU</option>
                <option value="IKK" <?php if(old('jenis', $indikator->jenis ?? '') === 'IKK'): echo 'selected'; endif; ?>>IKK</option>
                <option value="IKD" <?php if(old('jenis', $indikator->jenis ?? '') === 'IKD'): echo 'selected'; endif; ?>>IKD</option>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Satuan</label>
            <input type="text" name="satuan" value="<?php echo e(old('satuan', $indikator->satuan ?? '')); ?>" class="input" placeholder="Cth: %, Poin, Unit">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Nama Indikator <span class="text-red-500">*</span></label>
        <textarea name="nama" rows="2" required class="textarea"><?php echo e(old('nama', $indikator->nama ?? '')); ?></textarea>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Aspek IKD</label>
        <select name="aspek" class="select">
            <option value="">— Belum ditentukan —</option>
            <?php $__currentLoopData = [
                'ASPEK GEOGRAFI DAN DEMOGRAFI',
                'ASPEK KESEJAHTERAAN MASYARAKAT',
                'ASPEK DAYA SAING DAERAH',
                'ASPEK PELAYANAN UMUM',
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspekOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($aspekOption); ?>" <?php if(old('aspek', $indikator->aspek ?? '') === $aspekOption): echo 'selected'; endif; ?>>
                    <?php echo e(Str::headline(Str::lower(str_replace('ASPEK ', '', $aspekOption)))); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label class="flex items-start gap-3 rounded-xl border border-slate-200 p-3 bg-white">
            <input type="hidden" name="is_iku" value="0">
            <input type="checkbox" name="is_iku" value="1" class="mt-0.5 rounded border-slate-300 text-maroon-700 focus:ring-maroon-500"
                   <?php if((bool) old('is_iku', $indikator->is_iku ?? false)): echo 'checked'; endif; ?>>
            <span><span class="block text-sm font-medium text-slate-700">Termasuk IKU</span><span class="block text-xs text-slate-500">Ditampilkan pada kelompok Indikator Kinerja Utama.</span></span>
        </label>
        <label class="flex items-start gap-3 rounded-xl border border-slate-200 p-3 bg-white">
            <input type="hidden" name="is_makro" value="0">
            <input type="checkbox" name="is_makro" value="1" class="mt-0.5 rounded border-slate-300 text-maroon-700 focus:ring-maroon-500"
                   <?php if((bool) old('is_makro', $indikator->is_makro ?? $isMakroDefault ?? false)): echo 'checked'; endif; ?>>
            <span><span class="block text-sm font-medium text-slate-700">Termasuk indikator makro</span><span class="block text-xs text-slate-500">Ditampilkan pada sorotan makro publik.</span></span>
        </label>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">OPD Pengampu</label>
            <select name="opd_id" class="select">
                <option value="">— Tidak terikat OPD —</option>
                <?php $__currentLoopData = $opdList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($o->id); ?>" <?php if(old('opd_id', $indikator->opd_id ?? null) == $o->id): echo 'selected'; endif; ?>><?php echo e($o->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Urusan</label>
            <select name="urusan_id" class="select">
                <option value="">— Tidak terikat Urusan —</option>
                <?php $__currentLoopData = $urusanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php if(old('urusan_id', $indikator->urusan_id ?? null) == $u->id): echo 'selected'; endif; ?>><?php echo e($u->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Sasaran RPJMD Terkait</label>
            <select name="sasaran_rpjmd_id" class="select">
                <option value="">— Tidak ada —</option>
                <?php $__currentLoopData = $sasaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if(old('sasaran_rpjmd_id', $indikator->sasaran_rpjmd_id ?? null) == $s->id): echo 'selected'; endif; ?>><?php echo e(Str::limit($s->nama, 50)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Sumber Data</label>
            <input type="text" name="sumber_data" value="<?php echo e(old('sumber_data', $indikator->sumber_data ?? '')); ?>" class="input" placeholder="Cth: BPS, Dinas Pendidikan">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Keterangan sumber</label>
        <textarea name="keterangan" rows="3" class="textarea" placeholder="Catatan, proyeksi, atau rincian sumber data"><?php echo e(old('keterangan', $indikator->keterangan ?? '')); ?></textarea>
    </div>
</div>
<?php /**PATH /home/bappeli4/public_html/resources/views/indikator/_form.blade.php ENDPATH**/ ?>