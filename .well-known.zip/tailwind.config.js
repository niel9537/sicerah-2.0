import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.js',
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', 'Figtree', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                maroon: {
                    50:  '#fdf3f4',
                    100: '#fbe5e7',
                    200: '#f8ced2',
                    300: '#f2a7ad',
                    400: '#e97580',
                    500: '#dc4855',
                    600: '#c72c3d',
                    700: '#a72033',
                    800: '#8b1e30',
                    900: '#761d2e',
                    950: '#420b16',
                },
                brand: {
                    DEFAULT: '#8b1e30',
                    light:   '#a72033',
                    dark:    '#5c1220',
                },
            },
            boxShadow: {
                'soft': '0 2px 15px -3px rgba(139, 30, 48, 0.07), 0 10px 20px -2px rgba(139, 30, 48, 0.04)',
                'card': '0 4px 25px -5px rgba(0, 0, 0, 0.06)',
            },
            borderRadius: {
                'xl': '0.85rem',
                '2xl': '1.25rem',
            },
            backgroundImage: {
                'brand-gradient': 'linear-gradient(135deg, #8b1e30 0%, #c72c3d 55%, #dc4855 100%)',
                'brand-soft':     'linear-gradient(135deg, #fdf3f4 0%, #ffffff 100%)',
            },
            animation: {
                'fade-in':  'fadeIn 0.3s ease-in-out',
                'slide-in': 'slideIn 0.25s ease-out',
            },
            keyframes: {
                fadeIn:  { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
                slideIn: {
                    '0%': { transform: 'translateX(-10px)', opacity: 0 },
                    '100%': { transform: 'translateX(0)', opacity: 1 },
                },
            },
        },
    },

    plugins: [forms],
};