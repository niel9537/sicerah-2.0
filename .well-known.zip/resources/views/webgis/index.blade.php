@extends('layouts.public')

@section('title', 'WebGIS Nias Barat')

@push('head')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<style>
    #niasMap{position:relative;z-index:0;isolation:isolate;height:clamp(460px,68vh,760px);background:#e7ece9}
    .leaflet-container{font-family:'Inter',sans-serif;border-radius:1.25rem}
    .leaflet-popup-content-wrapper{border-radius:1rem;box-shadow:0 16px 45px -20px rgba(15,23,42,.55)}
    .leaflet-popup-content{margin:1rem;min-width:190px}
    @media(max-width:639px){#niasMap{height:min(64vh,580px);min-height:430px}}
</style>
@endpush

@section('content')
<section class="public-hero bg-[#4a0e18] text-white" style="background-color:#4a0e18!important;background-image:linear-gradient(135deg,#4a0e18 0%,#7f1d2d 58%,#4a0e18 100%)!important;color:#fff!important">
    <div class="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 py-10 sm:py-14">
        <p class="text-xs font-bold uppercase tracking-[.18em] text-[#e2b442]">Peta Tematik</p>
        <div class="mt-2 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-5">
            <div><h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight">WebGIS Kabupaten Nias Barat</h1><p class="mt-3 text-sm leading-6 text-white/65 max-w-2xl">Jelajahi indikator per desa. Pilih layer, tahun, dan desa untuk melihat sebaran data secara spasial.</p></div>
            @auth
                @if(in_array(auth()->user()->role, ['super_admin', 'admin_bappeda'], true))
                    <a href="{{ route('webgis.admin.index') }}" class="inline-flex self-start rounded-xl bg-white/10 border border-white/20 px-4 py-2.5 text-sm font-semibold hover:bg-white/15">Kelola Layer</a>
                @endif
            @endauth
        </div>
    </div>
</section>

<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6" x-data="{panel:true}">
    @if(!$activeLayer)
        <div class="public-card p-10 text-center"><p class="font-bold text-slate-900">Belum ada layer peta yang aktif</p><p class="text-sm text-slate-500 mt-1">Admin dapat menambahkan layer melalui dashboard.</p></div>
    @else
        <div class="grid lg:grid-cols-[310px_1fr] gap-4 items-start">
            <aside class="public-card p-4 sm:p-5 lg:sticky lg:top-24">
                <div class="grid sm:grid-cols-3 lg:grid-cols-1 gap-3">
                    <div><label class="block text-xs font-semibold text-slate-600 mb-1">Layer tematik</label><select id="layerSelect" class="select w-full" onchange="location.href=this.value">@foreach($layers as $layer)<option value="{{ route('webgis.index', ['layer' => $layer->slug]) }}" @selected($activeLayer->id === $layer->id)>{{ $layer->name }}</option>@endforeach</select></div>
                    <div><label class="block text-xs font-semibold text-slate-600 mb-1">Tahun</label><select id="yearSelect" class="select w-full">@forelse($years as $year)<option value="{{ $year }}">{{ $year }}</option>@empty<option value="{{ now()->year }}">Belum ada data</option>@endforelse</select></div>
                    <div><label class="block text-xs font-semibold text-slate-600 mb-1">Desa</label><select id="areaSelect" class="select w-full"><option value="">Semua desa</option>@foreach($areas->groupBy('district_name') as $district => $districtAreas)<optgroup label="{{ $district ?: 'Tanpa kecamatan' }}">@foreach($districtAreas as $area)<option value="{{ $area->code }}">{{ $area->name }}</option>@endforeach</optgroup>@endforeach</select></div>
                </div>
                <div class="mt-5 pt-5 border-t border-slate-100">
                    <p class="text-xs font-bold uppercase tracking-[.14em] text-slate-400">Ringkasan</p>
                    <dl class="mt-3 grid grid-cols-3 lg:grid-cols-1 gap-3 text-sm">
                        <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Terisi</dt><dd id="countValue" class="font-extrabold text-slate-900 mt-1">—</dd></div>
                        <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Minimum</dt><dd id="minValue" class="font-extrabold text-slate-900 mt-1">—</dd></div>
                        <div class="rounded-xl bg-slate-50 p-3"><dt class="text-xs text-slate-500">Maksimum</dt><dd id="maxValue" class="font-extrabold text-slate-900 mt-1">—</dd></div>
                    </dl>
                </div>
                <div class="mt-5"><div class="h-3 rounded-full" style="background:linear-gradient(90deg,{{ $activeLayer->color_from }},{{ $activeLayer->color_to }})"></div><div class="flex justify-between mt-1 text-[10px] text-slate-400"><span>Rendah</span><span>Tinggi</span></div></div>
            </aside>

            <div class="public-card p-2 sm:p-3 relative overflow-hidden">
                <div id="mapStatus" class="absolute left-5 top-5 z-[500] rounded-xl bg-white/95 shadow px-3 py-2 text-xs font-semibold text-slate-600">Memuat peta…</div>
                <div id="niasMap"></div>
            </div>
        </div>
    @endif
</section>
@endsection

@if($activeLayer)
@push('scripts')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
(function(){
    const map=L.map('niasMap',{zoomControl:false}).setView([1.02,97.48],10);
    L.control.zoom({position:'bottomright'}).addTo(map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
    const status=document.getElementById('mapStatus');
    const yearSelect=document.getElementById('yearSelect');
    const areaSelect=document.getElementById('areaSelect');
    const endpoint=@js(route('webgis.data'));
    const layerSlug=@js($activeLayer->slug);
    let geometry=null,layer=null,valueMap=new Map(),config=null;

    const escapeHtml=(value)=>String(value??'').replace(/[&<>'"]/g,(char)=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
    const hexToRgb=(hex)=>{const value=parseInt(hex.slice(1),16);return[(value>>16)&255,(value>>8)&255,value&255]};
    const color=(value,min,max)=>{if(value===null||Number.isNaN(Number(value)))return'#cbd5e1';const from=hexToRgb(config.color_from),to=hexToRgb(config.color_to);let ratio=max===min?0.65:(Number(value)-min)/(max-min);if(Array.isArray(config.breakpoints)&&config.breakpoints.length){const index=config.breakpoints.findIndex((point)=>Number(value)<=Number(point));ratio=(index<0?config.breakpoints.length:index)/Math.max(config.breakpoints.length,1)}ratio=Math.max(0,Math.min(1,ratio));return`rgb(${from.map((part,index)=>Math.round(part+(to[index]-part)*ratio)).join(',')})`};
    const codeOf=(feature)=>feature.properties.KDEPUM||feature.properties.kode_desa||feature.properties.KODE_DESA;
    const nameOf=(feature)=>feature.properties.WADMKD||feature.properties.NAMOBJ||'Desa';
    const districtOf=(feature)=>feature.properties.WADMKC||'';

    function draw(){
        if(layer)map.removeLayer(layer);
        const numeric=[...valueMap.values()].map((item)=>item.numeric_value).filter((value)=>value!==null).map(Number);
        const min=numeric.length?Math.min(...numeric):0,max=numeric.length?Math.max(...numeric):0,selected=areaSelect.value;
        document.getElementById('countValue').textContent=`${numeric.length} desa`;
        document.getElementById('minValue').textContent=numeric.length?min.toLocaleString('id-ID'):'—';
        document.getElementById('maxValue').textContent=numeric.length?max.toLocaleString('id-ID'):'—';
        layer=L.geoJSON(geometry,{filter:(feature)=>!selected||codeOf(feature)===selected,style:(feature)=>{const item=valueMap.get(codeOf(feature));return{color:'#fff',weight:1,fillColor:color(item?.numeric_value??null,min,max),fillOpacity:.82}},onEachFeature:(feature,polygon)=>{const item=valueMap.get(codeOf(feature));polygon.bindPopup(`<div><p style="font-size:11px;color:#64748b;margin:0 0 4px">${escapeHtml(districtOf(feature))}</p><p style="font-size:15px;font-weight:800;margin:0">${escapeHtml(nameOf(feature))}</p><div style="margin-top:12px;padding-top:10px;border-top:1px solid #e2e8f0"><span style="font-size:11px;color:#64748b">${escapeHtml(config.name)} ${escapeHtml(yearSelect.value)}</span><p style="font-size:22px;font-weight:800;color:#7f1d2d;margin:3px 0 0">${escapeHtml(item?.raw_value??'Belum tersedia')}</p><span style="font-size:11px;color:#64748b">${escapeHtml(config.unit??'')}</span></div></div>`);polygon.on({mouseover:(event)=>event.target.setStyle({weight:2,color:'#4a0e18',fillOpacity:.95}),mouseout:(event)=>layer.resetStyle(event.target)})}}).addTo(map);
        if(layer.getLayers().length)map.fitBounds(layer.getBounds(),{padding:[16,16]});
        status.textContent=numeric.length?'Peta siap':'Data numerik belum tersedia';setTimeout(()=>status.classList.add('hidden'),1800);
    }
    async function load(){
        status.classList.remove('hidden');status.textContent='Memuat data…';
        try{const response=await fetch(`${endpoint}?layer=${encodeURIComponent(layerSlug)}&year=${encodeURIComponent(yearSelect.value)}`,{headers:{Accept:'application/json'}});if(!response.ok)throw new Error('Data tidak dapat dimuat');const payload=await response.json();config=payload.layer;valueMap=new Map(payload.values.map((item)=>[item.area_code,item]));if(!geometry){const geoResponse=await fetch(config.geojson_url);if(!geoResponse.ok)throw new Error('GeoJSON tidak dapat dimuat');geometry=await geoResponse.json()}draw()}catch(error){status.textContent=error.message;status.classList.remove('hidden')}
    }
    yearSelect.addEventListener('change',load);areaSelect.addEventListener('change',draw);load();
    window.addEventListener('load',()=>map.invalidateSize());
})();
</script>
@endpush
@endif
