@extends($dashboard ? 'layouts.app' : 'layouts.public')
@section('title','WebGIS Nias Barat')
@section('content')
@include('webgis._style')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<div class="wg"><h1>WebGIS Nias Barat</h1><p>Jelajahi indikator pembangunan berdasarkan desa dan tahun.</p>
@if($dashboard && in_array(auth()->user()?->role,['super_admin','admin_bappeda'],true))<a class="wg-button" href="{{ route('webgis.admin.index') }}">Kelola peta tematik</a>@endif
@if($themes->isEmpty())<div class="wg-card">Belum ada tema yang dipublikasikan.</div>@else
<div class="wg-card"><div class="wg-filters"><label>Peta tematik<select id="wg-theme">@foreach($themes as $t)<option value="{{ route('webgis.data',$t) }}">{{ $t->name }}</option>@endforeach</select></label><label>Tahun<select id="wg-year"></select></label><label>Kecamatan<select id="wg-kec"><option value="">Semua kecamatan</option></select></label><label>Desa<select id="wg-desa"><option value="">Semua desa</option></select></label></div>
<div id="wg-status" class="wg-status" role="status" aria-live="polite">Memuat peta…</div><button type="button" class="wg-button" id="wg-retry" hidden>Coba lagi</button><div id="wg-map" class="wg-map"></div><div id="wg-legend" class="wg-legend"></div><p id="wg-source"></p><small>Angka ditampilkan sesuai satuan sumber. Nilai stunting bukan otomatis prevalensi (%).</small></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="{{ asset('webgis/map.js') }}"></script>
@endif</div>
@endsection