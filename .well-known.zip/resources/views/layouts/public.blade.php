<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'SICERAH') — Bappelitbangda Nias Barat</title>
    <meta name="description" content="@yield('meta_description', 'Portal publik indikator kinerja dan pembangunan Kabupaten Nias Barat.')">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('head')
    <style>
        :root{--sc-gold:#d9a72e;--sc-ink:#221015;--sc-maroon:#7f1d2d;--sc-maroon-dark:#4a0e18}
        html,body{font-family:'Inter',ui-sans-serif,system-ui,sans-serif;font-style:normal;overflow-x:hidden}
        em,i,.italic{font-style:normal!important}
        [x-cloak]{display:none!important}
        :focus-visible{outline:3px solid rgba(217,167,46,.6);outline-offset:2px;border-radius:.5rem}
        .reveal{opacity:0;transform:translateY(14px);transition:opacity .55s ease,transform .55s ease}
        .reveal.is-visible{opacity:1;transform:none}
        .public-card{background:rgba(255,255,255,.94);border:1px solid rgba(148,163,184,.18);border-radius:1.35rem;box-shadow:0 18px 55px -34px rgba(51,18,26,.42)}
        .public-hero{background-color:#4a0e18!important;background-image:linear-gradient(135deg,#4a0e18 0%,#7f1d2d 58%,#4a0e18 100%)!important;color:#fff!important}
        .public-profile{background:#0f172a!important;color:#fff!important}
        .public-footer{background:#260a11!important;color:rgba(255,255,255,.78)!important}
        .indicator-modal-shell{position:fixed!important;inset:0!important;z-index:2147483600!important;display:flex;align-items:center;justify-content:center;padding:24px;isolation:isolate}
        .indicator-modal-backdrop{position:absolute!important;inset:0!important;background:rgba(15,23,42,.72)!important;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
        .indicator-modal-panel{position:relative!important;z-index:1!important;width:min(920px,calc(100vw - 32px))!important;max-height:calc(100dvh - 32px)!important;overflow-y:auto!important;margin:auto!important;background:#fff!important;border-radius:24px!important;box-shadow:0 28px 80px -22px rgba(15,23,42,.62)!important;overscroll-behavior:contain}
        .indicator-chart-wrap{height:320px;position:relative}
        .public-bottom-nav{position:fixed!important;left:0!important;right:0!important;bottom:0!important;z-index:2147483000!important;width:100vw!important;height:72px!important;min-height:72px!important;padding:8px 8px 6px!important;box-sizing:border-box!important;background:#fff!important;transform:translate3d(0,0,0);-webkit-transform:translate3d(0,0,0);will-change:transform}
        .public-bottom-nav-items{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;width:100%}
        .public-bottom-nav-items>a{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:4px!important;min-width:0!important}
        @media(max-width:1023px){body{padding-bottom:80px!important}}
        @media(max-width:639px){.indicator-modal-shell{align-items:flex-end;padding:0}.indicator-modal-panel{width:100%!important;max-height:92dvh!important;margin:0!important;border-radius:24px 24px 0 0!important}.indicator-chart-wrap{height:280px}}
        @media(min-width:1024px){.public-bottom-nav{display:none!important}}
        @media(prefers-reduced-motion:reduce){.reveal{opacity:1!important;transform:none!important;transition:none!important}*{scroll-behavior:auto!important}}
    </style>
</head>
<body class="antialiased bg-[#fbfaf8] text-slate-800 pb-20 lg:pb-0">
    <header class="hidden lg:block sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-slate-200/70">
        <div class="max-w-7xl mx-auto px-6 h-[4.5rem] flex items-center justify-between">
            <a href="{{ route('landing') }}" class="flex items-center gap-3">
                <img src="{{ asset('images/logo2.png') }}" alt="Logo SICERAH" class="w-11 h-11 object-contain">
                <span class="leading-tight"><span class="block font-extrabold tracking-tight text-slate-900">SICERAH</span><span class="block text-[10px] uppercase tracking-[.2em] text-slate-500">Nias Barat</span></span>
            </a>
            <nav class="flex items-center gap-1" aria-label="Navigasi publik">
                <a href="{{ route('landing') }}#indikator" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-maroon-50 hover:text-maroon-800">Indikator</a>
                <a href="{{ route('landing') }}#kinerja" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-maroon-50 hover:text-maroon-800">Kinerja</a>
                <a href="{{ route('webgis.index') }}" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-maroon-50 hover:text-maroon-800">WebGIS</a>
                <a href="{{ route('jdih.index') }}" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-maroon-50 hover:text-maroon-800">JDIH</a>
                <a href="{{ route('landing') }}#profil" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-maroon-50 hover:text-maroon-800">Profil</a>
            </nav>
            <a href="{{ route('login') }}" class="btn-primary btn-sm">Masuk Admin</a>
        </div>
    </header>

    <div class="lg:hidden sticky top-0 z-30 h-14 px-4 flex items-center justify-between bg-white/92 backdrop-blur-xl border-b border-slate-200/70">
        <a href="{{ route('landing') }}" class="flex items-center gap-2.5">
            <img src="{{ asset('images/logo2.png') }}" alt="Logo SICERAH" class="w-9 h-9 object-contain">
            <span><span class="block text-sm font-extrabold leading-none text-slate-900">SICERAH</span><span class="block text-[9px] uppercase tracking-[.18em] text-slate-500 mt-1">Nias Barat</span></span>
        </a>
        <span class="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-maroon-50 text-maroon-800">Portal Publik</span>
    </div>

    <main>@yield('content')</main>

    <footer class="public-footer bg-[#260a11] text-white/75 mt-20" style="background:#260a11!important;color:rgba(255,255,255,.78)!important">
        <div class="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-3 gap-9">
            <div class="md:col-span-2">
                <div class="flex items-center gap-3 mb-4"><img src="{{ asset('images/logo2.png') }}" alt="Logo" class="w-10 h-10 object-contain"><span class="font-bold text-white">SICERAH Nias Barat</span></div>
                <p class="text-sm leading-7 max-w-2xl text-white/60">Portal data capaian, evaluasi, perencanaan pembangunan, dan informasi geospasial Kabupaten Nias Barat yang dikelola Bappelitbangda.</p>
            </div>
            <div id="kontak">
                <p class="text-xs font-semibold uppercase tracking-[.18em] text-white/40 mb-3">Kontak</p>
                <p class="text-sm leading-6">Kompleks Perkantoran Bupati Nias Barat, Lahomi</p>
                <p class="text-sm mt-2">bappelitbangda@niasbaratkab.go.id</p>
            </div>
        </div>
        <div class="border-t border-white/10 px-5 py-5 text-center text-xs text-white/40">© {{ date('Y') }} Pemerintah Kabupaten Nias Barat</div>
    </footer>

    <nav class="public-bottom-nav lg:hidden border-t border-slate-200 shadow-[0_-8px_30px_-18px_rgba(15,23,42,.45)]" style="position:fixed!important;left:0!important;right:0!important;bottom:0!important;z-index:2147483000!important;width:100vw!important;height:72px!important;padding:8px 8px 6px!important;background:#fff!important" aria-label="Navigasi bawah">
        <div class="public-bottom-nav-items">
            @php
                $bottomNav = [
                    ['label' => 'Beranda', 'href' => route('landing'), 'icon' => 'M3 11.5 12 4l9 7.5M5 10v10h14V10'],
                    ['label' => 'Indikator', 'href' => route('landing').'#indikator', 'icon' => 'M4 19V9m5 10V5m5 14v-7m5 7V3'],
                    ['label' => 'WebGIS', 'href' => route('webgis.index'), 'icon' => 'M9 18l-6 3V6l6-3m0 15 6 3m-6-3V3m6 18 6-3V3l-6 3m0 15V6'],
                    ['label' => 'JDIH', 'href' => route('jdih.index'), 'icon' => 'M6 4h12v16H6zM9 8h6m-6 4h6m-6 4h4'],
                    ['label' => 'Masuk', 'href' => route('login'), 'icon' => 'M10 17l5-5-5-5m5 5H3m11-9h6v18h-6'],
                ];
            @endphp
            @foreach($bottomNav as $item)
                <a href="{{ $item['href'] }}" class="flex flex-col items-center gap-1 text-[10px] font-medium text-slate-500 hover:text-maroon-800">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="{{ $item['icon'] }}"/></svg>
                    <span>{{ $item['label'] }}</span>
                </a>
            @endforeach
        </div>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const elements = document.querySelectorAll('.reveal');
            if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
                elements.forEach((element) => element.classList.add('is-visible'));
                return;
            }
            const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
                if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
            }), { threshold: .08 });
            elements.forEach((element) => observer.observe(element));
        });
    </script>
    @stack('scripts')
</body>
</html>
