@extends('layouts.public')

@section('title', 'JDIH')
@section('meta_description', 'Jaringan Dokumentasi dan Informasi Hukum Bappelitbangda Kabupaten Nias Barat — RPJMD, RKPD, Renstra, Renja, Peraturan Daerah, dan Peraturan Bupati terkait perencanaan pembangunan daerah.')

@section('content')

    <section class="bg-brand-gradient text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-16">
            <p class="text-xs font-semibold uppercase tracking-widest text-[var(--sc-gold-tint)] mb-3">Dokumentasi Hukum</p>
            <h1 class="font-display font-semibold text-3xl sm:text-4xl">JDIH Bappelitbangda</h1>
            <p class="text-white/80 text-sm sm:text-base mt-3 max-w-2xl leading-relaxed">
                Jaringan Dokumentasi dan Informasi Hukum: kumpulan dokumen perencanaan dan regulasi
                yang menjadi dasar hukum SICERAH — RPJMD, RKPD, Renstra, Renja, Peraturan Daerah,
                dan Peraturan Bupati Kabupaten Nias Barat.
            </p>
        </div>
    </section>

    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 pb-20">
        <div class="card p-4 sm:p-5 mb-6">
            <form method="GET" class="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input type="text" name="q" value="{{ $q }}" placeholder="Cari judul dokumen…" class="input sm:col-span-2">

                <select name="kategori" class="select" onchange="this.form.submit()">
                    <option value="">Semua Kategori</option>
                    @foreach($kategoriList as $key => $label)
                        <option value="{{ $key }}" @selected($kategori === $key)>{{ $label }}</option>
                    @endforeach
                </select>

                <select name="tahun" class="select" onchange="this.form.submit()">
                    <option value="">Semua Tahun</option>
                    @foreach($tahunList as $y)
                        <option value="{{ $y }}" @selected((string) $tahun === (string) $y)>{{ $y }}</option>
                    @endforeach
                </select>

                <button type="submit" class="btn-secondary justify-center sm:col-span-4">Terapkan Filter</button>
            </form>
        </div>

        @if($items->isEmpty())
            <x-ui.empty-state title="Tidak ada dokumen ditemukan" description="Coba ubah kata kunci atau filter kategori/tahun." />
        @else
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                @foreach($items as $doc)
                    <div class="card p-5 flex flex-col">
                        <div class="flex items-center justify-between mb-3">
                            <span class="badge-default">{{ $doc->kategoriLabel() }}</span>
                            @if($doc->tahun)<span class="text-xs text-slate-400">{{ $doc->tahun }}</span>@endif
                        </div>

                        <h3 class="font-semibold text-slate-800 text-sm leading-snug flex-1">{{ $doc->judul }}</h3>

                        @if($doc->nomor)
                            <p class="text-xs text-slate-500 mt-2">Nomor: {{ $doc->nomor }}</p>
                        @endif

                        @if($doc->ringkasan)
                            <p class="text-xs text-slate-500 mt-2 leading-relaxed">{{ Str::limit($doc->ringkasan, 130) }}</p>
                        @endif

                        <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                            <x-ui.updated-badge :at="$doc->updated_at" variant="text" label="Diperbarui" />
                            @if($doc->file_url)
                                <a href="{{ $doc->file_url }}" target="_blank" rel="noopener" class="text-xs font-semibold text-maroon-700 hover:text-maroon-900 inline-flex items-center gap-1">
                                    Lihat Dokumen
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                                </a>
                            @else
                                <span class="text-xs text-slate-400">Segera tersedia</span>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="mt-8">
                {{ $items->links() }}
            </div>
        @endif
    </section>

@endsection
