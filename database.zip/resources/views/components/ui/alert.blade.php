@props(['type' => 'info', 'dismissible' => true])

@php
    $styles = [
        'success' => ['bg' => 'bg-emerald-50 border-emerald-200 text-emerald-800',
                      'icon' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'],
        'error'   => ['bg' => 'bg-red-50 border-red-200 text-red-800',
                      'icon' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'],
        'warning' => ['bg' => 'bg-amber-50 border-amber-200 text-amber-800',
                      'icon' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>'],
        'info'    => ['bg' => 'bg-sky-50 border-sky-200 text-sky-800',
                      'icon' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'],
    ];
    $s = $styles[$type];
@endphp

<div x-data="{ show: true }" x-show="show" x-transition
     class="flex items-start gap-3 rounded-xl border p-4 {{ $s['bg'] }} mb-4">
    <div class="flex-shrink-0">{!! $s['icon'] !!}</div>
    <div class="flex-1 text-sm">{{ $slot }}</div>
    @if($dismissible)
        <button type="button" @click="show = false" class="text-current opacity-60 hover:opacity-100">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
    @endif
</div>