<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IndikatorTarget extends Model
{
    protected $table = 'indikator_target';
    public $timestamps = false;

    protected $fillable = ['indikator_id', 'tahun', 'target'];

    protected $casts = ['target' => 'decimal:4'];

    public function indikator(): BelongsTo
    {
        return $this->belongsTo(Indikator::class, 'indikator_id');
    }
}