<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IndikatorRealisasi extends Model
{
    protected $table = 'indikator_realisasi';
    public $timestamps = false;

    protected $fillable = [
        'indikator_id', 'tahun', 'triwulan', 'realisasi', 'status',
    ];

    protected $casts = ['realisasi' => 'decimal:4'];

    public function indikator(): BelongsTo
    {
        return $this->belongsTo(Indikator::class, 'indikator_id');
    }
}