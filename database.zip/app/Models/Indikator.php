<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Indikator extends Model
{
    protected $table = 'indikator';
    public $timestamps = false;

    protected $fillable = [
        'jenis', 'opd_id', 'urusan_id', 'sasaran_rpjmd_id',
        'nama', 'satuan', 'sumber_data',
    ];

    public function opd(): BelongsTo         { return $this->belongsTo(Opd::class, 'opd_id'); }
    public function urusan(): BelongsTo      { return $this->belongsTo(Urusan::class, 'urusan_id'); }
    public function sasaranRpjmd(): BelongsTo{ return $this->belongsTo(SasaranRpjmd::class, 'sasaran_rpjmd_id'); }

    public function targets(): HasMany       { return $this->hasMany(IndikatorTarget::class, 'indikator_id'); }
    public function realisasis(): HasMany    { return $this->hasMany(IndikatorRealisasi::class, 'indikator_id'); }

    public function scopeIku($q)  { return $q->where('jenis', 'IKU'); }
    public function scopeIkk($q)  { return $q->where('jenis', 'IKK'); }
    public function scopeIkd($q)  { return $q->where('jenis', 'IKD'); }
}