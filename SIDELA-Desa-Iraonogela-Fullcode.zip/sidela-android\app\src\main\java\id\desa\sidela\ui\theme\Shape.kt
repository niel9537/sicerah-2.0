package id.desa.sidela.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val Shapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

val CardShape = RoundedCornerShape(22.dp)
val PillShape = RoundedCornerShape(50.dp)
val ModalShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
